/****************************************************************************
** Meta object code from reading C++ file 'gamefieldviews.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../src/scene/gamefieldviews.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'gamefieldviews.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_GameTextureRenderer_t {
    QByteArrayData data[1];
    char stringdata0[20];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GameTextureRenderer_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GameTextureRenderer_t qt_meta_stringdata_GameTextureRenderer = {
    {
QT_MOC_LITERAL(0, 0, 19) // "GameTextureRenderer"

    },
    "GameTextureRenderer"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GameTextureRenderer[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void GameTextureRenderer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject GameTextureRenderer::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_GameTextureRenderer.data,
    qt_meta_data_GameTextureRenderer,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *GameTextureRenderer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GameTextureRenderer::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GameTextureRenderer.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int GameTextureRenderer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_GameObjectRepository_t {
    QByteArrayData data[1];
    char stringdata0[21];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GameObjectRepository_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GameObjectRepository_t qt_meta_stringdata_GameObjectRepository = {
    {
QT_MOC_LITERAL(0, 0, 20) // "GameObjectRepository"

    },
    "GameObjectRepository"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GameObjectRepository[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void GameObjectRepository::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject GameObjectRepository::staticMetaObject = { {
    &GameObjectRepositoryBase::staticMetaObject,
    qt_meta_stringdata_GameObjectRepository.data,
    qt_meta_data_GameObjectRepository,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *GameObjectRepository::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GameObjectRepository::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GameObjectRepository.stringdata0))
        return static_cast<void*>(this);
    return GameObjectRepositoryBase::qt_metacast(_clname);
}

int GameObjectRepository::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = GameObjectRepositoryBase::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_GameFieldView_t {
    QByteArrayData data[20];
    char stringdata0[236];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GameFieldView_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GameFieldView_t qt_meta_stringdata_GameFieldView = {
    {
QT_MOC_LITERAL(0, 0, 13), // "GameFieldView"
QT_MOC_LITERAL(1, 14, 9), // "addObject"
QT_MOC_LITERAL(2, 24, 0), // ""
QT_MOC_LITERAL(3, 25, 11), // "GameObject*"
QT_MOC_LITERAL(4, 37, 6), // "object"
QT_MOC_LITERAL(5, 44, 12), // "removeObject"
QT_MOC_LITERAL(6, 57, 11), // "placeObject"
QT_MOC_LITERAL(7, 69, 10), // "Coordinate"
QT_MOC_LITERAL(8, 80, 10), // "moveObject"
QT_MOC_LITERAL(9, 91, 11), // "newPosition"
QT_MOC_LITERAL(10, 103, 17), // "startMovingObject"
QT_MOC_LITERAL(11, 121, 15), // "endMovingObject"
QT_MOC_LITERAL(12, 137, 12), // "updateObject"
QT_MOC_LITERAL(13, 150, 12), // "selectObject"
QT_MOC_LITERAL(14, 163, 21), // "movingPositionChanged"
QT_MOC_LITERAL(15, 185, 14), // "unselectObject"
QT_MOC_LITERAL(16, 200, 14), // "SelectionState"
QT_MOC_LITERAL(17, 215, 4), // "None"
QT_MOC_LITERAL(18, 220, 8), // "Selected"
QT_MOC_LITERAL(19, 229, 6) // "Moving"

    },
    "GameFieldView\0addObject\0\0GameObject*\0"
    "object\0removeObject\0placeObject\0"
    "Coordinate\0moveObject\0newPosition\0"
    "startMovingObject\0endMovingObject\0"
    "updateObject\0selectObject\0"
    "movingPositionChanged\0unselectObject\0"
    "SelectionState\0None\0Selected\0Moving"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GameFieldView[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       1,   88, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   64,    2, 0x0a /* Public */,
       5,    1,   67,    2, 0x0a /* Public */,
       6,    1,   70,    2, 0x09 /* Protected */,
       8,    2,   73,    2, 0x09 /* Protected */,
      10,    0,   78,    2, 0x09 /* Protected */,
      11,    0,   79,    2, 0x09 /* Protected */,
      12,    0,   80,    2, 0x09 /* Protected */,
      13,    0,   81,    2, 0x09 /* Protected */,
      14,    2,   82,    2, 0x09 /* Protected */,
      15,    0,   87,    2, 0x09 /* Protected */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 7,    2,
    QMetaType::Void, 0x80000000 | 7, 0x80000000 | 7,    2,    9,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 7, 0x80000000 | 7,    2,    9,
    QMetaType::Void,

 // enums: name, alias, flags, count, data
      16,   16, 0x0,    3,   93,

 // enum data: key, value
      17, uint(GameFieldView::None),
      18, uint(GameFieldView::Selected),
      19, uint(GameFieldView::Moving),

       0        // eod
};

void GameFieldView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<GameFieldView *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->addObject((*reinterpret_cast< GameObject*(*)>(_a[1]))); break;
        case 1: _t->removeObject((*reinterpret_cast< GameObject*(*)>(_a[1]))); break;
        case 2: _t->placeObject((*reinterpret_cast< const Coordinate(*)>(_a[1]))); break;
        case 3: _t->moveObject((*reinterpret_cast< const Coordinate(*)>(_a[1])),(*reinterpret_cast< const Coordinate(*)>(_a[2]))); break;
        case 4: _t->startMovingObject(); break;
        case 5: _t->endMovingObject(); break;
        case 6: _t->updateObject(); break;
        case 7: _t->selectObject(); break;
        case 8: _t->movingPositionChanged((*reinterpret_cast< const Coordinate(*)>(_a[1])),(*reinterpret_cast< const Coordinate(*)>(_a[2]))); break;
        case 9: _t->unselectObject(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< GameObject* >(); break;
            }
            break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< GameObject* >(); break;
            }
            break;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject GameFieldView::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_GameFieldView.data,
    qt_meta_data_GameFieldView,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *GameFieldView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GameFieldView::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GameFieldView.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int GameFieldView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
