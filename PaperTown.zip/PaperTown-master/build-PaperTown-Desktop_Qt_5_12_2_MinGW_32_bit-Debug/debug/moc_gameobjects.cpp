/****************************************************************************
** Meta object code from reading C++ file 'gameobjects.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../src/core/gameobjects.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'gameobjects.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_GameObjectRepositoryBase_t {
    QByteArrayData data[1];
    char stringdata0[25];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GameObjectRepositoryBase_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GameObjectRepositoryBase_t qt_meta_stringdata_GameObjectRepositoryBase = {
    {
QT_MOC_LITERAL(0, 0, 24) // "GameObjectRepositoryBase"

    },
    "GameObjectRepositoryBase"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GameObjectRepositoryBase[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void GameObjectRepositoryBase::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject GameObjectRepositoryBase::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_GameObjectRepositoryBase.data,
    qt_meta_data_GameObjectRepositoryBase,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *GameObjectRepositoryBase::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GameObjectRepositoryBase::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GameObjectRepositoryBase.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int GameObjectRepositoryBase::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_GameFieldBase_t {
    QByteArrayData data[1];
    char stringdata0[14];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GameFieldBase_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GameFieldBase_t qt_meta_stringdata_GameFieldBase = {
    {
QT_MOC_LITERAL(0, 0, 13) // "GameFieldBase"

    },
    "GameFieldBase"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GameFieldBase[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void GameFieldBase::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject GameFieldBase::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_GameFieldBase.data,
    qt_meta_data_GameFieldBase,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *GameFieldBase::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GameFieldBase::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GameFieldBase.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int GameFieldBase::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_GameObjectProperty_t {
    QByteArrayData data[3];
    char stringdata0[28];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GameObjectProperty_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GameObjectProperty_t qt_meta_stringdata_GameObjectProperty = {
    {
QT_MOC_LITERAL(0, 0, 18), // "GameObjectProperty"
QT_MOC_LITERAL(1, 19, 7), // "updated"
QT_MOC_LITERAL(2, 27, 0) // ""

    },
    "GameObjectProperty\0updated\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GameObjectProperty[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   19,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void,

       0        // eod
};

void GameObjectProperty::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<GameObjectProperty *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updated(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (GameObjectProperty::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GameObjectProperty::updated)) {
                *result = 0;
                return;
            }
        }
    }
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject GameObjectProperty::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_GameObjectProperty.data,
    qt_meta_data_GameObjectProperty,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *GameObjectProperty::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GameObjectProperty::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GameObjectProperty.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int GameObjectProperty::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 1;
    }
    return _id;
}

// SIGNAL 0
void GameObjectProperty::updated()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
struct qt_meta_stringdata_GameObject_t {
    QByteArrayData data[21];
    char stringdata0[213];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GameObject_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GameObject_t qt_meta_stringdata_GameObject = {
    {
QT_MOC_LITERAL(0, 0, 10), // "GameObject"
QT_MOC_LITERAL(1, 11, 6), // "placed"
QT_MOC_LITERAL(2, 18, 0), // ""
QT_MOC_LITERAL(3, 19, 10), // "Coordinate"
QT_MOC_LITERAL(4, 30, 8), // "position"
QT_MOC_LITERAL(5, 39, 5), // "moved"
QT_MOC_LITERAL(6, 45, 11), // "oldPosition"
QT_MOC_LITERAL(7, 57, 11), // "newPosition"
QT_MOC_LITERAL(8, 69, 21), // "movingPositionChanged"
QT_MOC_LITERAL(9, 91, 7), // "updated"
QT_MOC_LITERAL(10, 99, 9), // "selecting"
QT_MOC_LITERAL(11, 109, 8), // "selected"
QT_MOC_LITERAL(12, 118, 10), // "unselected"
QT_MOC_LITERAL(13, 129, 13), // "startedMoving"
QT_MOC_LITERAL(14, 143, 11), // "endedMoving"
QT_MOC_LITERAL(15, 155, 8), // "declined"
QT_MOC_LITERAL(16, 164, 10), // "removeSelf"
QT_MOC_LITERAL(17, 175, 6), // "select"
QT_MOC_LITERAL(18, 182, 8), // "unselect"
QT_MOC_LITERAL(19, 191, 11), // "startMoving"
QT_MOC_LITERAL(20, 203, 9) // "endMoving"

    },
    "GameObject\0placed\0\0Coordinate\0position\0"
    "moved\0oldPosition\0newPosition\0"
    "movingPositionChanged\0updated\0selecting\0"
    "selected\0unselected\0startedMoving\0"
    "endedMoving\0declined\0removeSelf\0select\0"
    "unselect\0startMoving\0endMoving"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GameObject[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       1,  114, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      10,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   89,    2, 0x06 /* Public */,
       5,    2,   92,    2, 0x06 /* Public */,
       8,    2,   97,    2, 0x06 /* Public */,
       9,    0,  102,    2, 0x06 /* Public */,
      10,    0,  103,    2, 0x06 /* Public */,
      11,    0,  104,    2, 0x06 /* Public */,
      12,    0,  105,    2, 0x06 /* Public */,
      13,    0,  106,    2, 0x06 /* Public */,
      14,    0,  107,    2, 0x06 /* Public */,
      15,    0,  108,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      16,    0,  109,    2, 0x0a /* Public */,
      17,    0,  110,    2, 0x0a /* Public */,
      18,    0,  111,    2, 0x0a /* Public */,
      19,    0,  112,    2, 0x0a /* Public */,
      20,    0,  113,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 3,    6,    7,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 3,    6,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // properties: name, type, flags
       4, 0x80000000 | 3, 0x0009510b,

       0        // eod
};

void GameObject::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<GameObject *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->placed((*reinterpret_cast< const Coordinate(*)>(_a[1]))); break;
        case 1: _t->moved((*reinterpret_cast< const Coordinate(*)>(_a[1])),(*reinterpret_cast< const Coordinate(*)>(_a[2]))); break;
        case 2: _t->movingPositionChanged((*reinterpret_cast< const Coordinate(*)>(_a[1])),(*reinterpret_cast< const Coordinate(*)>(_a[2]))); break;
        case 3: _t->updated(); break;
        case 4: _t->selecting(); break;
        case 5: _t->selected(); break;
        case 6: _t->unselected(); break;
        case 7: _t->startedMoving(); break;
        case 8: _t->endedMoving(); break;
        case 9: _t->declined(); break;
        case 10: _t->removeSelf(); break;
        case 11: _t->select(); break;
        case 12: _t->unselect(); break;
        case 13: _t->startMoving(); break;
        case 14: _t->endMoving(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (GameObject::*)(const Coordinate & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GameObject::placed)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (GameObject::*)(const Coordinate & , const Coordinate & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GameObject::moved)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (GameObject::*)(const Coordinate & , const Coordinate & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GameObject::movingPositionChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (GameObject::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GameObject::updated)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (GameObject::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GameObject::selecting)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (GameObject::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GameObject::selected)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (GameObject::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GameObject::unselected)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (GameObject::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GameObject::startedMoving)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (GameObject::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GameObject::endedMoving)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (GameObject::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&GameObject::declined)) {
                *result = 9;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<GameObject *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< Coordinate*>(_v) = _t->position(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<GameObject *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setPosition(*reinterpret_cast< Coordinate*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject GameObject::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_GameObject.data,
    qt_meta_data_GameObject,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *GameObject::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GameObject::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GameObject.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int GameObject::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 15;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 1;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 1;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void GameObject::placed(const Coordinate & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void GameObject::moved(const Coordinate & _t1, const Coordinate & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void GameObject::movingPositionChanged(const Coordinate & _t1, const Coordinate & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void GameObject::updated()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void GameObject::selecting()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void GameObject::selected()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void GameObject::unselected()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void GameObject::startedMoving()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void GameObject::endedMoving()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void GameObject::declined()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}
struct qt_meta_stringdata_GroundObject_t {
    QByteArrayData data[1];
    char stringdata0[13];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_GroundObject_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_GroundObject_t qt_meta_stringdata_GroundObject = {
    {
QT_MOC_LITERAL(0, 0, 12) // "GroundObject"

    },
    "GroundObject"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GroundObject[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void GroundObject::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject GroundObject::staticMetaObject = { {
    &GameObject::staticMetaObject,
    qt_meta_stringdata_GroundObject.data,
    qt_meta_data_GroundObject,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *GroundObject::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GroundObject::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_GroundObject.stringdata0))
        return static_cast<void*>(this);
    return GameObject::qt_metacast(_clname);
}

int GroundObject::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = GameObject::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_StaticObject_t {
    QByteArrayData data[1];
    char stringdata0[13];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_StaticObject_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_StaticObject_t qt_meta_stringdata_StaticObject = {
    {
QT_MOC_LITERAL(0, 0, 12) // "StaticObject"

    },
    "StaticObject"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_StaticObject[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void StaticObject::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject StaticObject::staticMetaObject = { {
    &GameObject::staticMetaObject,
    qt_meta_stringdata_StaticObject.data,
    qt_meta_data_StaticObject,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *StaticObject::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *StaticObject::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_StaticObject.stringdata0))
        return static_cast<void*>(this);
    return GameObject::qt_metacast(_clname);
}

int StaticObject::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = GameObject::qt_metacall(_c, _id, _a);
    return _id;
}
struct qt_meta_stringdata_MovingObject_t {
    QByteArrayData data[1];
    char stringdata0[13];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MovingObject_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MovingObject_t qt_meta_stringdata_MovingObject = {
    {
QT_MOC_LITERAL(0, 0, 12) // "MovingObject"

    },
    "MovingObject"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MovingObject[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void MovingObject::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject MovingObject::staticMetaObject = { {
    &GameObject::staticMetaObject,
    qt_meta_stringdata_MovingObject.data,
    qt_meta_data_MovingObject,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MovingObject::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MovingObject::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MovingObject.stringdata0))
        return static_cast<void*>(this);
    return GameObject::qt_metacast(_clname);
}

int MovingObject::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = GameObject::qt_metacall(_c, _id, _a);
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
